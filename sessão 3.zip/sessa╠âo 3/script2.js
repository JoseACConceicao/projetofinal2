var matrix = [];
var matrix2 = [];

function setup() {
    createCanvas(1600, 1000);
    background(220);


    //criação matriz 1
    for (var i = 0; i <= 7; i++) {
        matrix[i] = [];
        for (var n = 0; n <= 7; n++) {
            if (n != i) {
                matrix[i][n] = 0;
            } else {
                matrix[i][n] = 1;
            }
        }
    }
    console.log(matrix);


    //criação matriz 2
    for (var i = 0; i <= 7; i++) {
        matrix2[i] = [];
        for (var n = 0; n <= 7; n++) {
            if (n != 7 - i) {
                matrix2[i][n] = 0;
            } else {
                matrix2[i][n] = 1;
            }
        }
    }
    console.log(matrix2);
}




function draw() {
    
    //matriz1
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {
            if (matrix[y][x] == 0) {
                noFill();
                stroke(100);
                rect(10 + x * 50, 10 + y * 50, 50, 50)
            } else {
                fill(0, 255, 0);
                rect(10 + x * 50, 10 + y * 50, 50, 50)
            }
        }
    }

    //matriz 2
    for (var y = 0; y < matrix2.length; y++) {
        for (var x = 0; x < matrix2[y].length; x++) {
            if (matrix2[y][x] == 0) {
                noFill();
                stroke(100);
                rect(10 + x * 50, 500 + y * 50, 50, 50)
            } else {
                fill(255, 0, 0);
                rect(10 + x * 50, 500 + y * 50, 50, 50)
            }
        }
    }

    //Fórmula matriz 2
    // for(var y = 0; y <= 7; y++){
    //     for(var x = 0; x <= 7; x++){
    //         if(x == 7-  y){
    //             stroke(100);
    //             fill(0, 255, 0);
    //             rect(x * 50, 500 + y * 50, 50, 50);

    //         }
    //         else{
    //             stroke(100);
    //             noFill();
    //             rect(x * 50, 500 + y * 50, 50, 50);
    //         }
    //     }           
    // }

    //matriz 3 com fórmula
    for (var y = 0; y <= 7; y++) {
        for (var x = 0; x <= 7; x++) {
            if (x <= 7 - y) {
                stroke(100);
                fill(255, 255, 0);
                rect(500 + x * 50, 10 + y * 50, 50, 50);

            }
            else {
                stroke(100);
                noFill();
                rect(500 + x * 50, 10 + y * 50, 50, 50);
            }
        }
    }

    //matriz 4 com fórmula
    for (var y = 0; y <= 7; y++) {
        for(var x = 0; x <= 7; x++){
            if((x + y) % 2 == 0){
                stroke(100);
                fill(0);
                rect(500 + x * 50, 500 + y * 50, 50, 50);
            }
            else{
                stroke(100);
                fill(255);
                rect(500 + x * 50, 500 + y * 50, 50, 50);
            }
        }
    }
    
    //matriz 5 com fórmula
    for(var y = 0; y <= 10; y++){
        for(var x = 0; x <= 10; x++){
            textSize(23);
            if(x != 0 && y != 0) {
                stroke(0);
                strokeWeight(1.5);
                fill(150);
                rect(1000 + x * 50, 10 + y * 50, 50, 50);
                var number = x * y;
                number = number.toString();
                noStroke();
                fill(0);
                text(number, 1010 + x * 50, 50 + y * 50);
            } else if(x == 0 && y != 0){
                stroke(0);
                strokeWeight(3);
                fill(150);
                rect(1000 + x * 50, 10 + y * 50, 50, 50);
                var number = y.toString();
                strokeWeight(1);
                fill(0);
                text(number, 1010 + x * 50, 50 + y * 50);
            } else if(y == 0 && x != 0){
                stroke(0);
                strokeWeight(3);
                fill(150);
                rect(1000 + x * 50, 10 + y * 50, 50, 50);
                var number = x.toString();
                strokeWeight(1);
                fill(0);
                text(number, 1010 + x * 50, 50 + y * 50);
            } else {
                stroke(0);
                strokeWeight(1.5);
                fill(150);
                rect(1000 + x * 50, 10 + y * 50, 50, 50); 
            }
        }
    }
}